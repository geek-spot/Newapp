#!/usr/bin/env bash
# نصب پنل روی لینوکس: sudo PORT=8000 bash install.sh
set -e
[ "$EUID" -ne 0 ] && { echo "با sudo اجرا کن: sudo bash install.sh"; exit 1; }
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
PORT="${PORT:-8000}"
SVC=wheelpanel

echo ">> نصب پیش‌نیازها"
if command -v apt-get >/dev/null; then apt-get update -y && apt-get install -y python3 python3-venv python3-pip
elif command -v dnf >/dev/null; then dnf install -y python3 python3-pip
elif command -v yum >/dev/null; then yum install -y python3 python3-pip
fi

id -u $SVC >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin -d "$APP_DIR" $SVC
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"
mkdir -p "$APP_DIR/data"
chown -R $SVC:$SVC "$APP_DIR"

if [ ! -f "$APP_DIR/data/auth.json" ]; then
  read -rp "نام کاربری ادمین: " ADMIN_USER
  while true; do
    read -rsp "رمز ادمین (حداقل ۸ کاراکتر): " ADMIN_PASS; echo
    [ ${#ADMIN_PASS} -ge 8 ] && break || echo "رمز کوتاه است."
  done
  ADMIN_PASS="$ADMIN_PASS" runuser -u $SVC -- "$APP_DIR/venv/bin/python" "$APP_DIR/app.py" setadmin "$ADMIN_USER"
fi

cat > /etc/systemd/system/$SVC.service <<UNIT
[Unit]
Description=MRT Wheel Studio panel
After=network-online.target
Wants=network-online.target

[Service]
User=$SVC
WorkingDirectory=$APP_DIR
Environment=PORT=$PORT
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/app.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now $SVC

echo ">> باز کردن پورت $PORT"
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow ${PORT}/tcp
elif command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port=${PORT}/tcp && firewall-cmd --reload
elif command -v iptables >/dev/null; then
  iptables -C INPUT -p tcp --dport $PORT -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport $PORT -j ACCEPT
  echo "(iptables دائمی نیست؛ برای ماندگاری iptables-persistent نصب کن)"
else
  echo "فایروالی پیدا نشد؛ شاید لازم نباشد."
fi

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo
echo "✅ پنل بالا آمد:  http://$IP:$PORT"
echo "اگر سرور ابری داری (AWS/Hetzner/...) پورت $PORT را در Security Group / Cloud Firewall هم باز کن."
echo "لاگ: journalctl -u $SVC -f      ریستارت: systemctl restart $SVC"
