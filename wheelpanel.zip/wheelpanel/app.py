# -*- coding: utf-8 -*-
"""MRT Wheel Studio — پنل وب برای ساخت عکس‌های کاتالوگ چرخ با Gemini"""
import os, io, sys, json, time, uuid, secrets, threading, queue, mimetypes, shutil, logging, tempfile
from pathlib import Path
from datetime import datetime
from functools import wraps

import requests
from PIL import Image, ImageOps
from flask import (Flask, request, session, redirect, url_for, render_template,
                   jsonify, send_from_directory, send_file, abort, flash)
from jinja2 import DictLoader
from werkzeug.security import generate_password_hash, check_password_hash

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
BATCH_DIR = DATA / "batches"
SETTINGS_FILE = DATA / "settings.json"
AUTH_FILE = DATA / "auth.json"
LOGO_FILE = BASE / "assets" / "logo.png"
for d in (DATA, BATCH_DIR):
    d.mkdir(parents=True, exist_ok=True)

logging.basicConfig(filename=str(DATA / "app.log"), level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("wheel")

BG = (13, 13, 13)
BOTTOM_START = 0.70          # ۳۰٪ پایین باید خالی باشد
BRIGHT_THR = 0.004           # بیش از این مقدار پیکسل روشن در ناحیه پایین = تخلف
EXTS = {".jpg", ".jpeg", ".png", ".webp"}

DEFAULT_PROMPT = """You are given two images. IMAGE 1 is the reference wheel photo. IMAGE 2 is the official MRT logo badge: a black circle with bold white "MRT" lettering and a red diagonal slash accent. Reproduce IMAGE 2 exactly (same letter shapes, same red accent, same proportions) on the wheel's center cap; do not redraw, restyle, or alter the logo in any way.

A professional, high-end e-commerce studio photograph of the exact automotive wheel shown in IMAGE 1, faithfully preserving its original spoke design, exact lug nut hole count and bolt pattern, surface finish, and color scheme.

Composition & Framing (Strict Consistency): Framed in a vertical 3:4 aspect ratio. The wheel is positioned in the upper two-thirds of the frame with a consistent safe margin at the top, leaving the bottom 30% of the image completely empty, dark, and unobstructed for text overlays.

Camera Angle & Perspective: The wheel is captured from a fixed 45-degree three-quarter studio angle turned to the right, prominently revealing the wide metallic outer barrel and depth of the drum on the left side, matching a standardized catalog perspective.

Details & Center Cap: Replace or update the center cap with a sleek dark center cap featuring the distinct red and silver "MRT" logo from IMAGE 2 in the middle, correctly foreshortened to match the wheel's viewing angle, while keeping the surrounding hub and lug holes identical to the source wheel. Every edge, spoke contour, and metallic texture is tack-sharp, clean, and brand-new, with all original background clutter or overlaid text completely removed.

Studio Environment & Lighting: Seamless dark studio gradient backdrop transitioning from deep charcoal (#1c1c1c) behind the wheel to smoky black (#0d0d0d) toward the outer edges and lower third. Below the wheel, a soft, natural contact shadow and a very faint, subtle reflection rest on the dark floor, fading smoothly into a completely blank, non-reflective black space at the bottom. Professional three-point studio lighting: a soft key light from the upper left highlighting the wheel face, a subtle fill light from the right for dimension, and a crisp rim light defining the outer barrel edge on the left. Shot on an 85mm lens, commercial catalog quality, photorealistic, no watermarks, no borders, no added text."""

DEFAULTS = {
    "gemini_keys": [], "tg_token": "", "tg_chat_id": "",
    "model": "gemini-3-pro-image-preview", "fallback_model": "gemini-2.5-flash-image",
    "judge_model": "gemini-2.5-flash", "image_size": "2K",
    "candidates": 2, "workers": 3, "auto_send": True, "prompt": "",
}

# ───────────────────────── تنظیمات و احراز هویت ─────────────────────────
_slock = threading.Lock()


def load_settings():
    with _slock:
        s = dict(DEFAULTS)
        if SETTINGS_FILE.exists():
            try:
                s.update(json.loads(SETTINGS_FILE.read_text("utf-8")))
            except Exception:
                log.exception("settings read failed")
        return s


def save_settings(s):
    with _slock:
        tmp = SETTINGS_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(s, ensure_ascii=False, indent=2), "utf-8")
        os.chmod(tmp, 0o600)
        tmp.replace(SETTINGS_FILE)


def load_auth():
    if AUTH_FILE.exists():
        return json.loads(AUTH_FILE.read_text("utf-8"))
    return None


def set_admin(username, password):
    AUTH_FILE.write_text(json.dumps({"username": username, "hash": generate_password_hash(password)}), "utf-8")
    os.chmod(AUTH_FILE, 0o600)


def secret_key():
    f = DATA / "secret.key"
    if not f.exists():
        f.write_text(secrets.token_hex(32))
        os.chmod(f, 0o600)
    return f.read_text().strip()


# ───────────────────────── مدیریت کلیدها ─────────────────────────
class KeyPool:
    """هر کلید در هر لحظه فقط یک درخواست فعال دارد؛ کلیدهای محدودشده موقتاً کنار می‌روند."""

    def __init__(self):
        self.cv = threading.Condition()
        self.busy, self.dead, self.cool, self.last = set(), set(), {}, {}

    def reset(self):
        with self.cv:
            self.dead.clear(); self.cool.clear(); self.cv.notify_all()

    def acquire(self, keys, deadline):
        with self.cv:
            while True:
                now = time.time()
                alive = [k for k in keys if k not in self.dead]
                if not alive or now > deadline:
                    return None
                avail = [k for k in alive if k not in self.busy and self.cool.get(k, 0) <= now]
                if avail:
                    k = min(avail, key=lambda x: self.last.get(x, 0))
                    self.busy.add(k); self.last[k] = now
                    return k
                waits = [self.cool[k] - now for k in alive if k not in self.busy and self.cool.get(k, 0) > now]
                self.cv.wait(timeout=min(waits) + 0.5 if waits else 3)

    def release(self, k, cool=0, dead=False):
        with self.cv:
            self.busy.discard(k)
            if dead: self.dead.add(k)
            if cool: self.cool[k] = time.time() + cool
            self.cv.notify_all()

    def stats(self, keys):
        now = time.time()
        with self.cv:
            return {
                "total": len(keys),
                "dead": len([k for k in keys if k in self.dead]),
                "limited": len([k for k in keys if self.cool.get(k, 0) > now]),
                "busy": len([k for k in keys if k in self.busy]),
            }


POOL = KeyPool()
MODEL_OVERRIDE = {"fallback": False}


def classify(e):
    m = str(e)
    ml = m.lower()
    if "429" in m or "RESOURCE_EXHAUSTED" in m or "quota" in ml:
        return "rate", (3600 if ("perday" in ml or "per day" in ml) else 65)
    if "503" in m or "UNAVAILABLE" in m or "overloaded" in ml or "500" in m and "INTERNAL" in m:
        return "overload", 0
    if "404" in m or "NOT_FOUND" in m:
        return "notfound", 0
    if "401" in m or "403" in m or "API_KEY_INVALID" in m or "PERMISSION_DENIED" in m or "API key" in m:
        return "auth", 0
    return "other", 0


# ───────────────────────── پردازش تصویر ─────────────────────────
def fit_34(im):
    w, h = im.size
    r = w / h
    if abs(r - 0.75) < 0.0015:
        return im
    if abs(r / 0.75 - 1) < 0.03:                      # اختلاف کم: کراپ
        if r > 0.75:
            nw = round(h * 0.75); l = (w - nw) // 2
            return im.crop((l, 0, l + nw, h))
        return im.crop((0, 0, w, round(w / 0.75)))
    if r > 0.75:                                       # اختلاف زیاد: پدینگ تیره
        c = Image.new("RGB", (w, round(w / 0.75)), BG); c.paste(im, (0, 0)); return c
    nw = round(h * 0.75)
    c = Image.new("RGB", (nw, h), BG); c.paste(im, ((nw - w) // 2, 0)); return c


def bottom_bright(im):
    w, h = im.size
    y0 = int(h * (BOTTOM_START + 0.02))
    reg = im.crop((0, y0, w, h)).convert("L")
    return sum(reg.histogram()[70:]) / float(w * (h - y0))


def fix_bottom(im):
    w, h = im.size
    y0, y1 = int(h * (BOTTOM_START - 0.04)), int(h * BOTTOM_START)
    col = [0 if y < y0 else (255 if y >= y1 else int(255 * (y - y0) / max(1, y1 - y0))) for y in range(h)]
    mask = Image.new("L", (1, h)); mask.putdata(col); mask = mask.resize((w, h))
    return Image.composite(Image.new("RGB", (w, h), BG), im, mask)


def prep_input(raw):
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert("RGB")
    if max(im.size) > 3000:
        im.thumbnail((3000, 3000), Image.LANCZOS)
    b = io.BytesIO(); im.save(b, "JPEG", quality=95)
    return b.getvalue()


def small_jpeg(im, side=1024, q=85):
    c = im.copy(); c.thumbnail((side, side), Image.LANCZOS)
    b = io.BytesIO(); c.save(b, "JPEG", quality=q); return b.getvalue()


# ───────────────────────── Gemini ─────────────────────────
def gen_image(key, model, size, prompt, wheel_jpg, logo_png):
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=key, http_options=types.HttpOptions(timeout=240000))
    ic = {"aspect_ratio": "3:4"}
    if model.startswith("gemini-3"):
        ic["image_size"] = size
    cfg = types.GenerateContentConfig(response_modalities=["IMAGE"], image_config=types.ImageConfig(**ic))
    resp = client.models.generate_content(model=model, config=cfg, contents=[
        prompt,
        types.Part.from_bytes(data=wheel_jpg, mime_type="image/jpeg"),
        types.Part.from_bytes(data=logo_png, mime_type="image/png"),
    ])
    for c in resp.candidates or []:
        for p in (c.content.parts if c.content else []) or []:
            if getattr(p, "inline_data", None) and p.inline_data.data:
                return p.inline_data.data
    raise RuntimeError("EMPTY_IMAGE: مدل تصویری برنگرداند")


def judge(key, model, wheel_jpg, logo_png, cand_imgs):
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=key, http_options=types.HttpOptions(timeout=120000))
    txt = (
        "You are a strict QA reviewer for automotive wheel catalog images. Image 1 is the ORIGINAL wheel photo, "
        "image 2 is the official MRT logo, the remaining images are numbered candidates (0..N-1, in order). "
        "Score each candidate 0-10 on: (a) spoke design identical to the original, (b) lug hole count and bolt pattern identical, "
        "(c) MRT logo on center cap matches image 2 and is legible, (d) no text/watermark/artifacts, (e) sharp, clean, photorealistic, "
        "(f) wheel in upper two-thirds with empty dark bottom. Reply ONLY JSON: "
        '{"scores":[...],"best":<index>,"reason":"short"}'
    )
    parts = [txt, types.Part.from_bytes(data=wheel_jpg, mime_type="image/jpeg"),
             types.Part.from_bytes(data=logo_png, mime_type="image/png")]
    for im in cand_imgs:
        parts.append(types.Part.from_bytes(data=small_jpeg(im), mime_type="image/jpeg"))
    resp = client.models.generate_content(model=model, contents=parts,
                                          config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0))
    d = json.loads(resp.text)
    best = int(d.get("best", 0))
    return (best if 0 <= best < len(cand_imgs) else 0), d.get("scores"), d.get("reason", "")


# ───────────────────────── وضعیت دسته‌ها ─────────────────────────
STATE = {}
_blk = threading.RLock()
Q = queue.Queue()


def bdir(bid): return BATCH_DIR / bid


def save_batch(bid):
    with _blk:
        f = bdir(bid) / "batch.json"
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps(STATE[bid], ensure_ascii=False), "utf-8")
        tmp.replace(f)


def set_item(bid, iid, **kw):
    with _blk:
        b = STATE.get(bid)
        if not b: return
        for it in b["items"]:
            if it["id"] == iid:
                it.update(kw)
                break
        save_batch(bid)


def load_all():
    for d in sorted(BATCH_DIR.iterdir()):
        f = d / "batch.json"
        if f.exists():
            try:
                b = json.loads(f.read_text("utf-8"))
            except Exception:
                continue
            STATE[b["id"]] = b
            for it in b["items"]:
                if it["status"] in ("running", "queued"):
                    it["status"] = "queued"; it["stage"] = "در صف"
                    Q.put((b["id"], it["id"]))


def tg_send(path: Path, caption, S):
    if not S.get("tg_token") or not S.get("tg_chat_id"):
        return False, "توکن یا Chat ID تنظیم نشده"
    p, tmp = path, None
    try:
        if path.stat().st_size > 48 * 1024 * 1024:
            tmp = Path(tempfile.mktemp(suffix=".jpg"))
            Image.open(path).convert("RGB").save(tmp, "JPEG", quality=95)
            p = tmp
        with open(p, "rb") as f:
            r = requests.post(f"https://api.telegram.org/bot{S['tg_token']}/sendDocument",
                              data={"chat_id": S["tg_chat_id"], "caption": caption[:1000]},
                              files={"document": (p.name if tmp is None else path.stem + ".jpg", f)}, timeout=300)
        if r.ok:
            return True, ""
        return False, r.text[:200].replace(S["tg_token"], "***")
    except Exception as e:
        return False, str(e)[:200].replace(S["tg_token"], "***")
    finally:
        if tmp and tmp.exists(): tmp.unlink()


def process_item(bid, iid):
    S = load_settings()
    b = STATE[bid]
    it = next(x for x in b["items"] if x["id"] == iid)
    keys = S["gemini_keys"]
    if not keys:
        raise RuntimeError("هیچ API Key تنظیم نشده")
    set_item(bid, iid, status="running", stage="آماده‌سازی", error="", started=time.time())
    wheel = prep_input((bdir(bid) / "in" / it["file"]).read_bytes())
    logo = LOGO_FILE.read_bytes()
    prompt = S["prompt"].strip() or DEFAULT_PROMPT
    n = max(1, min(4, int(S["candidates"])))
    model = S["fallback_model"] if MODEL_OVERRIDE["fallback"] else S["model"]
    deadline = time.time() + 2 * 3600
    cands, attempts, last_err = [], 0, ""

    while len(cands) < n and attempts < n * 5:
        set_item(bid, iid, stage=f"ساخت کاندید {len(cands) + 1} از {n}")
        key = POOL.acquire(keys, deadline)
        if key is None:
            raise RuntimeError("کلید معتبر/در دسترس نیست. " + last_err)
        try:
            attempts += 1
            data = gen_image(key, model, S["image_size"], prompt, wheel, logo)
            POOL.release(key)
            cands.append(Image.open(io.BytesIO(data)).convert("RGB"))
        except Exception as e:
            kind, wait = classify(e)
            last_err = f"{kind}: {str(e)[:160]}"
            log.warning("gen error %s", last_err)
            if kind == "rate":
                attempts -= 1; POOL.release(key, cool=wait)
            elif kind == "auth":
                attempts -= 1; POOL.release(key, dead=True)
            elif kind == "notfound":
                POOL.release(key); model = S["fallback_model"]; MODEL_OVERRIDE["fallback"] = True
            elif kind == "overload":
                POOL.release(key); time.sleep(10)
            else:
                POOL.release(key); time.sleep(3)
    if not cands:
        raise RuntimeError(last_err or "خروجی تصویری دریافت نشد")

    # اصلاح نسبت ۳:۴ و بررسی ۳۰٪ پایین
    cands = [fit_34(c) for c in cands]
    scores = [bottom_bright(c) for c in cands]
    good = [i for i, s in enumerate(scores) if s <= BRIGHT_THR]
    pool_idx = good if good else sorted(range(len(cands)), key=lambda i: scores[i])
    chosen, note = pool_idx[0], ""
    if len(pool_idx) > 1:
        set_item(bid, iid, stage="داوری بین کاندیدها")
        try:
            k = POOL.acquire(keys, time.time() + 300)
            if k:
                try:
                    j, sc, why = judge(k, S["judge_model"], wheel, logo, [cands[i] for i in pool_idx])
                    chosen = pool_idx[j]; note = f"داور: {why}"[:200]
                    POOL.release(k)
                except Exception as e:
                    kind, wait = classify(e)
                    POOL.release(k, cool=wait if kind == "rate" else 0, dead=(kind == "auth"))
                    note = "داور در دسترس نبود، کاندید اول انتخاب شد"
        except Exception:
            log.exception("judge failed")
    final = cands[chosen]
    if scores[chosen] > BRIGHT_THR:
        final = fix_bottom(final)
        note = (note + " | " if note else "") + ("ناحیه پایین اصلاح شد" if scores[chosen] < 0.03 else "⚠ چرخ وارد ناحیه پایین شده، بررسی کنید")

    od = bdir(bid) / "out"; td = bdir(bid) / "thumb"; cd = bdir(bid) / "cand"
    for d in (od, td, cd): d.mkdir(exist_ok=True)
    final.save(od / f"{iid}.png", optimize=False)
    t = final.copy(); t.thumbnail((480, 640)); t.save(td / f"{iid}.jpg", "JPEG", quality=82)
    cand_files = []
    for i, c in enumerate(cands):
        nm = f"{iid}_{i + 1}.jpg"; c.save(cd / nm, "JPEG", quality=92); cand_files.append(nm)
    set_item(bid, iid, status="done", stage="تمام", note=note, cands=cand_files, finished=time.time(),
             size=list(final.size))

    if b.get("send_tg") and S.get("auto_send"):
        set_item(bid, iid, stage="ارسال به تلگرام")
        ok, err = tg_send(od / f"{iid}.png", it["name"], S)
        set_item(bid, iid, stage="تمام", tg=ok, tg_error=err)


def worker(idx):
    while True:
        S = load_settings()
        allowed = max(1, min(int(S["workers"]), max(1, len(S["gemini_keys"])), 8))
        if idx >= allowed:
            time.sleep(2); continue
        try:
            bid, iid = Q.get(timeout=2)
        except queue.Empty:
            continue
        try:
            if bid in STATE:
                process_item(bid, iid)
        except Exception as e:
            log.exception("item failed")
            set_item(bid, iid, status="failed", stage="خطا", error=str(e)[:300], finished=time.time())
        finally:
            Q.task_done()


_started = False


def start_workers():
    global _started
    if _started: return
    _started = True
    load_all()
    for i in range(8):
        threading.Thread(target=worker, args=(i,), daemon=True).start()


# ───────────────────────── Flask ─────────────────────────
app = Flask(__name__)
app.secret_key = secret_key()
app.config.update(MAX_CONTENT_LENGTH=600 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
                  SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE") == "1",
                  PERMANENT_SESSION_LIFETIME=7 * 24 * 3600)
from templates_data import TEMPLATES
app.jinja_loader = DictLoader(TEMPLATES)

FAILS = {}


def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("ok"):
            return redirect(url_for("login"))
        return f(*a, **k)
    return w


@app.before_request
def csrf_guard():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method == "POST" and request.endpoint != "login":
        if request.form.get("csrf") != session.get("csrf") and request.headers.get("X-CSRF") != session.get("csrf"):
            abort(400, "CSRF")


@app.context_processor
def inject():
    return {"csrf": session.get("csrf", ""), "now": datetime.now}


@app.after_request
def headers(r):
    r.headers["X-Frame-Options"] = "DENY"
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Cache-Control"] = "no-store" if request.endpoint != "files" else "private, max-age=300"
    return r


@app.route("/login", methods=["GET", "POST"])
def login():
    auth = load_auth()
    ip = request.remote_addr
    if request.method == "POST":
        f = FAILS.get(ip, [0, 0])
        if f[1] > time.time():
            flash("تلاش‌های ناموفق زیاد بود؛ چند دقیقه بعد دوباره امتحان کن.")
        elif auth and request.form.get("u") == auth["username"] and check_password_hash(auth["hash"], request.form.get("p", "")):
            session.clear(); session["ok"] = True; session.permanent = True
            session["csrf"] = secrets.token_hex(16)
            FAILS.pop(ip, None)
            return redirect(url_for("dashboard"))
        else:
            f[0] += 1
            if f[0] >= 5: f = [0, time.time() + 300]
            FAILS[ip] = f
            time.sleep(1)
            flash("نام کاربری یا رمز اشتباه است.")
    return render_template("login.html", configured=bool(auth))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def batch_summary(b):
    its = b["items"]
    c = {k: sum(1 for i in its if i["status"] == k) for k in ("queued", "running", "done", "failed")}
    return c


@app.route("/")
@login_required
def dashboard():
    S = load_settings()
    batches = sorted(STATE.values(), key=lambda x: x["created"], reverse=True)
    rows = [(b, batch_summary(b)) for b in batches]
    return render_template("dashboard.html", rows=rows, S=S, st=POOL.stats(S["gemini_keys"]), qsize=Q.qsize(),
                           datefmt=lambda t: datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M"))


@app.route("/upload", methods=["POST"])
@login_required
def upload():
    files = [f for f in request.files.getlist("files") if f.filename]
    files = [f for f in files if Path(f.filename).suffix.lower() in EXTS]
    if not files:
        flash("هیچ عکس معتبری انتخاب نشد (jpg / png / webp)."); return redirect(url_for("dashboard"))
    if not load_settings()["gemini_keys"]:
        flash("اول در بخش تنظیمات حداقل یک API Key اضافه کن."); return redirect(url_for("settings"))
    bid = datetime.now().strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    (bdir(bid) / "in").mkdir(parents=True)
    items = []
    for f in files:
        iid = uuid.uuid4().hex[:8]
        ext = Path(f.filename).suffix.lower()
        fn = iid + ext
        f.save(bdir(bid) / "in" / fn)
        items.append({"id": iid, "name": Path(f.filename).name, "file": fn, "status": "queued", "stage": "در صف",
                      "error": "", "note": "", "tg": False, "tg_error": "", "cands": []})
    STATE[bid] = {"id": bid, "created": time.time(), "send_tg": bool(request.form.get("send_tg")), "items": items}
    save_batch(bid)
    for it in items: Q.put((bid, it["id"]))
    return redirect(url_for("batch", bid=bid))


def get_batch(bid):
    b = STATE.get(bid)
    if not b: abort(404)
    return b


@app.route("/batch/<bid>")
@login_required
def batch(bid):
    return render_template("batch.html", b=get_batch(bid))


@app.route("/api/batch/<bid>")
@login_required
def api_batch(bid):
    b = get_batch(bid)
    return jsonify({"items": b["items"], "sum": batch_summary(b), "queue": Q.qsize()})


@app.route("/batch/<bid>/retry", methods=["POST"])
@login_required
def retry(bid):
    b = get_batch(bid)
    for it in b["items"]:
        if it["status"] == "failed":
            set_item(bid, it["id"], status="queued", stage="در صف", error="")
            Q.put((bid, it["id"]))
    return redirect(url_for("batch", bid=bid))


@app.route("/batch/<bid>/delete", methods=["POST"])
@login_required
def delete(bid):
    get_batch(bid)
    STATE.pop(bid, None)
    shutil.rmtree(bdir(bid), ignore_errors=True)
    return redirect(url_for("dashboard"))


@app.route("/batch/<bid>/send", methods=["POST"])
@login_required
def send_all(bid):
    b = get_batch(bid); S = load_settings()
    only = request.form.get("item")
    def run():
        for it in b["items"]:
            if it["status"] == "done" and (not only or it["id"] == only):
                ok, err = tg_send(bdir(bid) / "out" / f"{it['id']}.png", it["name"], S)
                set_item(bid, it["id"], tg=ok, tg_error=err)
    threading.Thread(target=run, daemon=True).start()
    flash("ارسال به تلگرام شروع شد؛ نتیجه در جدول نمایش داده می‌شود.")
    return redirect(url_for("batch", bid=bid))


@app.route("/batch/<bid>/zip")
@login_required
def zip_batch(bid):
    b = get_batch(bid)
    od = bdir(bid) / "out"
    if not od.exists() or not any(od.iterdir()): abort(404)
    tmp = Path(tempfile.mkdtemp()) / bid
    shutil.make_archive(str(tmp), "zip", od)
    return send_file(str(tmp) + ".zip", as_attachment=True, download_name=f"{bid}.zip")


@app.route("/files/<bid>/<kind>/<name>")
@login_required
def files(bid, kind, name):
    if kind not in ("in", "out", "thumb", "cand"): abort(404)
    get_batch(bid)
    dl = request.args.get("dl")
    out_name = None
    if kind == "out" and dl:
        iid = Path(name).stem
        it = next((x for x in STATE[bid]["items"] if x["id"] == iid), None)
        out_name = (Path(it["name"]).stem + "_MRT.png") if it else name
    return send_from_directory(bdir(bid) / kind, name, as_attachment=bool(dl), download_name=out_name)


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    S = load_settings()
    if request.method == "POST":
        f = request.form
        keep = set(f.getlist("keep"))
        keys = [k for k in S["gemini_keys"] if k[-6:] in keep]
        for line in (f.get("new_keys", "")).replace(",", "\n").splitlines():
            line = line.strip()
            if line and line not in keys: keys.append(line)
        S["gemini_keys"] = keys
        if f.get("tg_token", "").strip(): S["tg_token"] = f["tg_token"].strip()
        S["tg_chat_id"] = f.get("tg_chat_id", "").strip()
        S["model"] = f.get("model", S["model"]).strip() or DEFAULTS["model"]
        S["fallback_model"] = f.get("fallback_model", S["fallback_model"]).strip() or DEFAULTS["fallback_model"]
        S["judge_model"] = f.get("judge_model", S["judge_model"]).strip() or DEFAULTS["judge_model"]
        S["image_size"] = f.get("image_size", "2K") if f.get("image_size") in ("1K", "2K", "4K") else "2K"
        S["candidates"] = max(1, min(4, int(f.get("candidates", 2) or 2)))
        S["workers"] = max(1, min(8, int(f.get("workers", 3) or 3)))
        S["auto_send"] = bool(f.get("auto_send"))
        S["prompt"] = "" if f.get("prompt", "").strip() == DEFAULT_PROMPT.strip() else f.get("prompt", "").strip()
        save_settings(S)
        POOL.reset(); MODEL_OVERRIDE["fallback"] = False
        flash("تنظیمات ذخیره شد.")
        return redirect(url_for("settings"))
    return render_template("settings.html", S=S, default_prompt=DEFAULT_PROMPT,
                           st=POOL.stats(S["gemini_keys"]), auth=load_auth())


@app.route("/settings/test_tg", methods=["POST"])
@login_required
def test_tg():
    S = load_settings()
    if not S["tg_token"] or not S["tg_chat_id"]:
        flash("اول توکن و Chat ID را ذخیره کن."); return redirect(url_for("settings"))
    try:
        r = requests.post(f"https://api.telegram.org/bot{S['tg_token']}/sendMessage",
                          data={"chat_id": S["tg_chat_id"], "text": "✅ اتصال پنل MRT Wheel Studio برقرار است."}, timeout=20)
        flash("پیام تست ارسال شد ✅" if r.ok else "خطا: " + r.text[:200].replace(S["tg_token"], "***"))
    except Exception as e:
        flash("خطا: " + str(e)[:200].replace(S["tg_token"], "***"))
    return redirect(url_for("settings"))


@app.route("/settings/password", methods=["POST"])
@login_required
def change_pass():
    auth = load_auth()
    if not check_password_hash(auth["hash"], request.form.get("old", "")):
        flash("رمز فعلی اشتباه است.")
    elif len(request.form.get("new", "")) < 8:
        flash("رمز جدید باید حداقل ۸ کاراکتر باشد.")
    else:
        set_admin(request.form.get("user") or auth["username"], request.form["new"])
        flash("رمز عوض شد.")
    return redirect(url_for("settings"))


@app.route("/api/status")
@login_required
def api_status():
    S = load_settings()
    return jsonify({"keys": POOL.stats(S["gemini_keys"]), "queue": Q.qsize()})


def main():
    if len(sys.argv) >= 3 and sys.argv[1] == "setadmin":
        pw = os.environ.get("ADMIN_PASS")
        if not pw:
            import getpass; pw = getpass.getpass("رمز جدید: ")
        if len(pw) < 8:
            sys.exit("رمز باید حداقل ۸ کاراکتر باشد.")
        set_admin(sys.argv[2], pw); print("ادمین ثبت شد."); return
    start_workers()
    from waitress import serve
    port = int(os.environ.get("PORT", "8000"))
    print(f"Panel running on 0.0.0.0:{port}")
    serve(app, host="0.0.0.0", port=port, threads=8)


if __name__ == "__main__":
    main()
