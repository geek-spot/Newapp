MRT Wheel Studio — نصب روی سرور لینوکس

1) پوشه را روی سرور کپی کن و در آن اجرا کن:
   sudo PORT=8000 bash install.sh
   (نام کاربری و رمز ادمین را می‌پرسد، سرویس systemd می‌سازد و پورت را در فایروال باز می‌کند)
2) آدرس http://IP-سرور:8000 را باز کن، وارد شو و در «تنظیمات» کلیدهای Gemini، توکن ربات و Chat ID را بگذار.

دستورات مفید:
  journalctl -u wheelpanel -f          لاگ زنده
  systemctl restart wheelpanel         ریستارت
  sudo -u wheelpanel venv/bin/python app.py setadmin USER   ریست رمز ادمین
