# -*- coding: utf-8 -*-
TEMPLATES = {}

TEMPLATES["base.html"] = r"""<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{% block title %}MRT Wheel Studio{% endblock %}</title>
<style>
:root{--bg:#0f1115;--card:#171a21;--line:#262b36;--tx:#e8eaf0;--mut:#8b93a5;--red:#e32626;--ok:#2fbf71;--warn:#e8a93a}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font-family:Tahoma,"Segoe UI",sans-serif;font-size:15px;line-height:1.7}
a{color:#8ab4ff;text-decoration:none}
nav{display:flex;gap:16px;align-items:center;padding:12px 20px;background:var(--card);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:5}
nav b{color:#fff}nav b span{color:var(--red)}nav .sp{flex:1}
.wrap{max-width:1100px;margin:0 auto;padding:20px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:18px}
h2{margin:0 0 12px;font-size:18px}h3{margin:18px 0 8px;font-size:15px;color:var(--mut)}
input[type=text],input[type=password],input[type=number],select,textarea{width:100%;background:#0f1218;border:1px solid var(--line);color:var(--tx);border-radius:8px;padding:9px 11px;font:inherit}
textarea{min-height:90px;direction:ltr;text-align:left;font-family:monospace;font-size:13px}
input[dir=ltr]{direction:ltr;text-align:left}
label{display:block;margin:10px 0 4px;color:var(--mut);font-size:13px}
.btn{background:var(--red);color:#fff;border:0;border-radius:8px;padding:9px 18px;font:inherit;cursor:pointer}
.btn.sec{background:#2a3040}.btn.sm{padding:4px 12px;font-size:13px}.btn.danger{background:#7a1f1f}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.stat{background:#0f1218;border:1px solid var(--line);border-radius:10px;padding:12px;text-align:center}
.stat b{display:block;font-size:22px}.stat span{color:var(--mut);font-size:12px}
table{width:100%;border-collapse:collapse}th,td{padding:9px 8px;border-bottom:1px solid var(--line);text-align:right;vertical-align:middle}
th{color:var(--mut);font-weight:normal;font-size:13px}
.badge{display:inline-block;padding:2px 10px;border-radius:20px;font-size:12px}
.b-queued{background:#2a3040}.b-running{background:#3b3a14;color:#f2d24b}.b-done{background:#123824;color:var(--ok)}.b-failed{background:#401616;color:#ff7b7b}
.flash{background:#1d2a44;border:1px solid #2f4575;padding:10px 14px;border-radius:8px;margin-bottom:14px}
.thumb{width:64px;height:86px;object-fit:cover;border-radius:6px;background:#000;border:1px solid var(--line)}
.row{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.mut{color:var(--mut);font-size:13px}
.keyrow{display:flex;gap:10px;align-items:center;padding:6px 0;direction:ltr;font-family:monospace}
.bar{height:8px;background:#0f1218;border-radius:8px;overflow:hidden;margin:8px 0}.bar i{display:block;height:100%;background:var(--ok);width:0;transition:width .4s}
.login{max-width:360px;margin:12vh auto}
@media(max-width:700px){.hide-m{display:none}}
</style></head><body>
{% if session.get('ok') %}<nav><b>MRT <span>Wheel</span> Studio</b><a href="{{ url_for('dashboard') }}">داشبورد</a><a href="{{ url_for('settings') }}">تنظیمات</a><span class="sp"></span><a href="{{ url_for('logout') }}">خروج</a></nav>{% endif %}
<div class="wrap">
{% with m = get_flashed_messages() %}{% for x in m %}<div class="flash">{{ x }}</div>{% endfor %}{% endwith %}
{% block body %}{% endblock %}
</div></body></html>"""

TEMPLATES["login.html"] = r"""{% extends "base.html" %}{% block body %}
<div class="card login"><h2>ورود به پنل</h2>
{% if not configured %}<div class="flash">ادمین هنوز ساخته نشده. روی سرور اجرا کن:<br><code dir="ltr">venv/bin/python app.py setadmin USERNAME</code></div>{% endif %}
<form method="post"><label>نام کاربری</label><input type="text" name="u" dir="ltr" autofocus autocomplete="username">
<label>رمز عبور</label><input type="password" name="p" dir="ltr" autocomplete="current-password">
<p><button class="btn" style="width:100%">ورود</button></p></form></div>{% endblock %}"""

TEMPLATES["dashboard.html"] = r"""{% extends "base.html" %}{% block body %}
<div class="card"><h2>وضعیت</h2><div class="grid">
<div class="stat"><b>{{ st.total }}</b><span>کلید Gemini</span></div>
<div class="stat"><b>{{ st.limited }}</b><span>کلید محدودشده (موقت)</span></div>
<div class="stat"><b>{{ st.dead }}</b><span>کلید نامعتبر</span></div>
<div class="stat"><b>{{ qsize }}</b><span>عکس در صف</span></div>
<div class="stat"><b>{{ S.candidates }}</b><span>کاندید برای هر عکس</span></div>
<div class="stat"><b>{{ S.image_size }}</b><span>کیفیت خروجی</span></div></div></div>

<div class="card"><h2>آپلود عکس چرخ‌ها</h2>
<form method="post" action="{{ url_for('upload') }}" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="{{ csrf }}">
<input type="file" name="files" accept="image/*" multiple required>
<p><label style="display:inline"><input type="checkbox" name="send_tg" value="1" {% if S.auto_send %}checked{% endif %}> بعد از ساخت، به تلگرام هم ارسال شود</label></p>
<button class="btn">شروع پردازش</button></form></div>

<div class="card"><h2>دسته‌ها</h2>
{% if not rows %}<p class="mut">هنوز چیزی آپلود نشده.</p>{% else %}
<table><tr><th>زمان</th><th>تعداد</th><th>انجام‌شده</th><th>در حال کار / صف</th><th>ناموفق</th><th></th></tr>
{% for b,c in rows %}<tr><td>{{ datefmt(b.created) }}</td><td>{{ b['items']|length }}</td><td>{{ c.done }}</td><td>{{ c.running + c.queued }}</td><td>{{ c.failed }}</td>
<td><a class="btn sm sec" href="{{ url_for('batch', bid=b.id) }}">مشاهده</a></td></tr>{% endfor %}</table>{% endif %}</div>
<script>setTimeout(function(){location.reload()},15000)</script>
{% endblock %}"""

TEMPLATES["batch.html"] = r"""{% extends "base.html" %}{% block body %}
<div class="card"><div class="row"><h2 style="margin:0">دسته {{ b.id }}</h2><span class="sp" style="flex:1"></span>
<a class="btn sm sec" href="{{ url_for('zip_batch', bid=b.id) }}">دانلود همه (zip)</a>
<form method="post" action="{{ url_for('send_all', bid=b.id) }}" style="margin:0"><input type="hidden" name="csrf" value="{{ csrf }}"><button class="btn sm sec">ارسال همه به تلگرام</button></form>
<form method="post" action="{{ url_for('retry', bid=b.id) }}" style="margin:0"><input type="hidden" name="csrf" value="{{ csrf }}"><button class="btn sm sec">تلاش مجدد ناموفق‌ها</button></form>
<form method="post" action="{{ url_for('delete', bid=b.id) }}" style="margin:0" onsubmit="return confirm('حذف شود؟')"><input type="hidden" name="csrf" value="{{ csrf }}"><button class="btn sm danger">حذف</button></form></div>
<div class="bar"><i id="pb"></i></div><div class="mut" id="sum"></div></div>
<div class="card"><table><thead><tr><th>خروجی</th><th>نام</th><th>وضعیت</th><th class="hide-m">توضیح</th><th></th></tr></thead><tbody id="rows"></tbody></table></div>
<script>
const BID="{{ b.id }}", CSRF="{{ csrf }}", BASE="/files/"+BID+"/";
const LBL={queued:"در صف",running:"در حال کار",done:"انجام شد",failed:"ناموفق"};
function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function row(it){
  let img = it.status==="done" ? `<a href="${BASE}out/${it.id}.png" target="_blank"><img class="thumb" src="${BASE}thumb/${it.id}.jpg"></a>` : `<div class="thumb"></div>`;
  let st = `<span class="badge b-${it.status}">${LBL[it.status]}</span><div class="mut">${esc(it.status==="failed"?it.error:it.stage)}</div>`;
  let tg = it.status==="done" ? (it.tg ? "✅ تلگرام" : (it.tg_error ? "❌ "+esc(it.tg_error) : "")) : "";
  let note = esc(it.note) + (tg ? `<div>${tg}</div>` : "");
  let act = "";
  if(it.status==="done"){
    act = `<a class="btn sm sec" href="${BASE}out/${it.id}.png?dl=1">دانلود</a> `;
    act += `<form method="post" action="/batch/${BID}/send" style="display:inline"><input type="hidden" name="csrf" value="${CSRF}"><input type="hidden" name="item" value="${it.id}"><button class="btn sm sec">تلگرام</button></form>`;
    if((it.cands||[]).length>1){ act += `<div class="mut">کاندیدها: ` + it.cands.map((c,i)=>`<a target="_blank" href="${BASE}cand/${c}">${i+1}</a>`).join(" ") + `</div>`; }
  }
  return `<tr><td>${img}</td><td dir="ltr" style="text-align:right">${esc(it.name)}</td><td>${st}</td><td class="hide-m mut">${note}</td><td>${act}</td></tr>`;
}
let busy=false;
async function tick(){
  if(busy) return; busy=true;
  try{
    const r=await fetch("/api/batch/"+BID); if(!r.ok) return; const d=await r.json();
    document.getElementById("rows").innerHTML=d.items.map(row).join("");
    const n=d.items.length, s=d.sum, fin=s.done+s.failed;
    document.getElementById("pb").style.width=(n?fin*100/n:0)+"%";
    document.getElementById("sum").textContent=`انجام‌شده ${s.done} از ${n} — در کار ${s.running} — صف ${s.queued} — ناموفق ${s.failed}`;
  }catch(e){} finally{busy=false}
}
tick(); setInterval(tick,3000);
</script>{% endblock %}"""

TEMPLATES["settings.html"] = r"""{% extends "base.html" %}{% block body %}
<form method="post" class="card"><input type="hidden" name="csrf" value="{{ csrf }}">
<h2>کلیدهای Gemini</h2>
{% for k in S.gemini_keys %}<div class="keyrow"><input type="checkbox" name="keep" value="{{ k[-6:] }}" checked> <span>{{ k[:4] }}••••••••{{ k[-6:] }}</span></div>{% endfor %}
{% if S.gemini_keys %}<div class="mut">تیک را بردار تا کلید حذف شود.</div>{% endif %}
<label>افزودن کلید جدید (هر خط یکی)</label><textarea name="new_keys" placeholder="AIza..."></textarea>

<h3>تلگرام</h3>
<label>توکن ربات {% if S.tg_token %}(ذخیره شده؛ برای تغییر مقدار جدید بنویس){% endif %}</label>
<input type="password" name="tg_token" dir="ltr" autocomplete="off" placeholder="{{ '••••••••' if S.tg_token else '123456:ABC...' }}">
<label>Chat ID عددی</label><input type="text" name="tg_chat_id" dir="ltr" value="{{ S.tg_chat_id }}">
<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="auto_send" {% if S.auto_send %}checked{% endif %}> ارسال خودکار نتیجه به تلگرام (پیش‌فرض آپلودها)</label>

<h3>مدل و کیفیت</h3>
<div class="grid">
<div><label>مدل اصلی</label><input type="text" name="model" dir="ltr" value="{{ S.model }}"></div>
<div><label>مدل جایگزین</label><input type="text" name="fallback_model" dir="ltr" value="{{ S.fallback_model }}"></div>
<div><label>مدل داور</label><input type="text" name="judge_model" dir="ltr" value="{{ S.judge_model }}"></div>
<div><label>کیفیت</label><select name="image_size">{% for z in ['1K','2K','4K'] %}<option {% if S.image_size==z %}selected{% endif %}>{{ z }}</option>{% endfor %}</select></div>
<div><label>تعداد کاندید (۱ تا ۴)</label><input type="number" name="candidates" min="1" max="4" value="{{ S.candidates }}"></div>
<div><label>پردازش هم‌زمان (۱ تا ۸)</label><input type="number" name="workers" min="1" max="8" value="{{ S.workers }}"></div></div>
<div class="mut">پردازش هم‌زمان عملاً به‌اندازه‌ی تعداد کلیدها محدود می‌شود. بیش از یک کاندید یعنی مصرف سهمیه‌ی چند برابر.</div>

<h3>پرامپت</h3>
<textarea name="prompt" style="min-height:260px">{{ S.prompt or default_prompt }}</textarea>
<p><button class="btn">ذخیره</button></p></form>

<div class="card"><h2>تست تلگرام</h2><form method="post" action="{{ url_for('test_tg') }}"><input type="hidden" name="csrf" value="{{ csrf }}"><button class="btn sec">ارسال پیام تست</button></form></div>

<div class="card"><h2>تغییر نام کاربری / رمز</h2><form method="post" action="{{ url_for('change_pass') }}"><input type="hidden" name="csrf" value="{{ csrf }}">
<label>نام کاربری</label><input type="text" name="user" dir="ltr" value="{{ auth.username }}">
<label>رمز فعلی</label><input type="password" name="old" dir="ltr">
<label>رمز جدید (حداقل ۸ کاراکتر)</label><input type="password" name="new" dir="ltr">
<p><button class="btn sec">تغییر</button></p></form></div>{% endblock %}"""
