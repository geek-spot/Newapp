package com.mdviewer.app.model

data class AppSettings(
    val backgroundDarkness: Int = 75,       // 0-100 (0=white, 100=black)
    val textColor: String = "#F5F0E8",      // Warm white for Persian readability
    val textSize: Int = 17,                  // sp
    val lineSpacing: Float = 1.8f,          // multiplier
    val paragraphSpacing: Int = 16,         // dp
    val rtlEnabled: Boolean = true,
    val codeHighlight: Boolean = true,
    val hyphenation: Boolean = false,
    val fontFamily: String = "vazir"
)
