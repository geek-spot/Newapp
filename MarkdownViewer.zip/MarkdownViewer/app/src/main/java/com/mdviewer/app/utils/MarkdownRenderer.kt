package com.mdviewer.app.utils

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import io.noties.markwon.Markwon
import io.noties.markwon.core.MarkwonTheme
import io.noties.markwon.ext.strikethrough.StrikethroughPlugin
import io.noties.markwon.ext.tables.TablePlugin
import io.noties.markwon.ext.tasklist.TaskListPlugin
import io.noties.markwon.html.HtmlPlugin
import com.mdviewer.app.model.AppSettings

class MarkdownRenderer(private val context: Context) {

    fun render(content: String, settings: AppSettings): Spanned {
        val textColor = Color.parseColor(settings.textColor)
        val accentColor = deriveAccentColor(settings.backgroundDarkness)
        val codeBackgroundColor = deriveCodeBgColor(settings.backgroundDarkness)
        val headingColor = derivedHeadingColor(settings.textColor, settings.backgroundDarkness)

        val vazirTypeface = try {
            Typeface.createFromAsset(context.assets, "fonts/Vazirmatn-Regular.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT
        }

        val vazirBold = try {
            Typeface.createFromAsset(context.assets, "fonts/Vazirmatn-Bold.ttf")
        } catch (e: Exception) {
            Typeface.DEFAULT_BOLD
        }

        val markwon = Markwon.builder(context)
            .usePlugin(StrikethroughPlugin.create())
            .usePlugin(TablePlugin.create(context))
            .usePlugin(TaskListPlugin.create(context))
            .usePlugin(HtmlPlugin.create())
            .usePlugin(
                io.noties.markwon.core.CorePlugin.create()
            )
            .usePlugin(
                io.noties.markwon.AbstractMarkwonPlugin.create { plugin ->
                    plugin.theme()
                        .headingTextSizeMultipliers(floatArrayOf(2.0f, 1.7f, 1.45f, 1.25f, 1.1f, 1.0f))
                        .headingBreakColor(Color.argb(60, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                        .headingBreakHeight(2)
                        .blockMargin(context.resources.getDimensionPixelSize(com.mdviewer.app.R.dimen.block_margin))
                        .blockQuoteWidth(context.resources.getDimensionPixelSize(com.mdviewer.app.R.dimen.quote_width))
                        .blockQuoteColor(accentColor)
                        .codeTextColor(textColor)
                        .codeBackgroundColor(codeBackgroundColor)
                        .codeBlockTextColor(textColor)
                        .codeBlockBackgroundColor(codeBackgroundColor)
                        .codeBlockMargin(context.resources.getDimensionPixelSize(com.mdviewer.app.R.dimen.code_margin))
                        .linkColor(accentColor)
                        .thematicBreakColor(Color.argb(80, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                        .thematicBreakHeight(2)
                        .tableRowOddBackground(Color.argb(20, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                        .tableRowEvenBackground(Color.TRANSPARENT)
                        .tableBorderColor(Color.argb(60, Color.red(textColor), Color.green(textColor), Color.blue(textColor)))
                        .tableBorderWidth(1)
                        .build()
                }
            )
            .build()

        return markwon.toMarkdown(content)
    }

    private fun deriveAccentColor(darkness: Int): Int {
        return when {
            darkness < 40 -> Color.parseColor("#5B8DB8")   // muted blue for light bg
            darkness < 70 -> Color.parseColor("#7EB8A5")   // teal for mid bg
            else -> Color.parseColor("#A0C4B8")             // soft mint for dark bg
        }
    }

    private fun deriveCodeBgColor(darkness: Int): Int {
        return when {
            darkness < 40 -> Color.parseColor("#EDE8E0")
            darkness < 70 -> Color.parseColor("#252535")
            else -> Color.parseColor("#1A1A28")
        }
    }

    private fun derivedHeadingColor(textColor: String, darkness: Int): Int {
        val base = Color.parseColor(textColor)
        return if (darkness > 50) {
            Color.argb(255,
                (Color.red(base) + 20).coerceAtMost(255),
                (Color.green(base) + 20).coerceAtMost(255),
                (Color.blue(base) + 20).coerceAtMost(255)
            )
        } else {
            base
        }
    }
}
