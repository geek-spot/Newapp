package com.mdviewer.app.ui

import android.animation.ValueAnimator
import android.graphics.Color
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.mdviewer.app.R
import com.mdviewer.app.databinding.ActivitySettingsBinding
import com.mdviewer.app.model.AppSettings
import com.mdviewer.app.utils.PreferencesManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefsManager: PreferencesManager
    private lateinit var settings: AppSettings

    private val textColorOptions = listOf(
        Pair("#FFFFFF", "سفید خالص"),
        Pair("#F5F0E8", "کرم گرم"),
        Pair("#E8E0D0", "کاغذ قدیمی"),
        Pair("#D4C5A9", "بژ طبیعی"),
        Pair("#A8D8B9", "سبز آرام"),
        Pair("#B8D4E8", "آبی ملایم"),
        Pair("#E8C4C4", "صورتی کم‌رنگ"),
        Pair("#2C2C2C", "تیره"),
        Pair("#1A1A1A", "خیلی تیره")
    )

    private var selectedColorIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefsManager = PreferencesManager(this)
        settings = prefsManager.getSettings()

        setupToolbar()
        setupUI()
        loadCurrentSettings()
        setupListeners()
        updatePreview()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.settingsToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        binding.settingsTitleText.text = getString(R.string.settings_title)
    }

    private fun setupUI() {
        // Setup color chips
        binding.colorChipsContainer.removeAllViews()
        textColorOptions.forEachIndexed { index, (hex, name) ->
            val chip = layoutInflater.inflate(
                R.layout.item_color_chip, binding.colorChipsContainer, false
            ) as View

            val circleView = chip.findViewById<View>(R.id.colorCircle)
            val labelView = chip.findViewById<android.widget.TextView>(R.id.colorLabel)

            circleView.setBackgroundColor(Color.parseColor(hex))
            labelView.text = name
            labelView.setTypeface(android.graphics.Typeface.create("vazir", android.graphics.Typeface.NORMAL))

            chip.setOnClickListener {
                selectedColorIndex = index
                updateColorSelection()
                settings = settings.copy(textColor = hex)
                updatePreview()
            }

            binding.colorChipsContainer.addView(chip)
        }
    }

    private fun loadCurrentSettings() {
        binding.seekbarDarkness.progress = settings.backgroundDarkness
        binding.seekbarTextSize.progress = settings.textSize - 12
        binding.seekbarLineSpacing.progress = ((settings.lineSpacing - 1.2f) * 20).toInt()
        binding.seekbarParagraphSpacing.progress = settings.paragraphSpacing
        binding.switchRtl.isChecked = settings.rtlEnabled
        binding.switchCodeHighlight.isChecked = settings.codeHighlight
        binding.switchHyphenation.isChecked = settings.hyphenation

        selectedColorIndex = textColorOptions.indexOfFirst { it.first == settings.textColor }
            .takeIf { it >= 0 } ?: 0

        updateColorSelection()
        updateLabels()
    }

    private fun setupListeners() {
        binding.seekbarDarkness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                settings = settings.copy(backgroundDarkness = progress)
                updateLabels()
                updatePreview()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { saveSettings() }
        })

        binding.seekbarTextSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                settings = settings.copy(textSize = progress + 12)
                updateLabels()
                updatePreview()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { saveSettings() }
        })

        binding.seekbarLineSpacing.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                settings = settings.copy(lineSpacing = 1.2f + progress / 20f)
                updateLabels()
                updatePreview()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { saveSettings() }
        })

        binding.seekbarParagraphSpacing.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                settings = settings.copy(paragraphSpacing = progress)
                updateLabels()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) { saveSettings() }
        })

        binding.switchRtl.setOnCheckedChangeListener { _, checked ->
            settings = settings.copy(rtlEnabled = checked)
            saveSettings()
            updatePreview()
        }

        binding.switchCodeHighlight.setOnCheckedChangeListener { _, checked ->
            settings = settings.copy(codeHighlight = checked)
            saveSettings()
        }

        binding.switchHyphenation.setOnCheckedChangeListener { _, checked ->
            settings = settings.copy(hyphenation = checked)
            saveSettings()
        }

        binding.btnResetDefaults.setOnClickListener {
            settings = AppSettings()
            loadCurrentSettings()
            saveSettings()
            updatePreview()
        }
    }

    private fun updateColorSelection() {
        for (i in 0 until binding.colorChipsContainer.childCount) {
            val chip = binding.colorChipsContainer.getChildAt(i)
            val isSelected = i == selectedColorIndex
            chip.scaleX = if (isSelected) 1.1f else 1.0f
            chip.scaleY = if (isSelected) 1.1f else 1.0f
            chip.elevation = if (isSelected) 12f else 2f
        }
    }

    private fun updateLabels() {
        val darknessPercent = settings.backgroundDarkness
        binding.labelDarkness.text = when {
            darknessPercent < 20 -> "روشن ☀️"
            darknessPercent < 45 -> "متوسط 🌤"
            darknessPercent < 70 -> "تاریک 🌙"
            else -> "شب ⬛"
        }

        binding.labelTextSize.text = "${settings.textSize}sp"
        binding.labelLineSpacing.text = String.format("%.1fx", settings.lineSpacing)
        binding.labelParagraphSpacing.text = "${settings.paragraphSpacing}dp"
    }

    private fun updatePreview() {
        val bgAlpha = settings.backgroundDarkness
        val bgColor = when {
            bgAlpha < 30 -> interpolateColor(Color.parseColor("#FAFAF8"), Color.parseColor("#F0EDE8"), bgAlpha / 30f)
            bgAlpha < 60 -> interpolateColor(Color.parseColor("#F0EDE8"), Color.parseColor("#1A1A2E"), (bgAlpha - 30) / 30f)
            bgAlpha < 80 -> interpolateColor(Color.parseColor("#1A1A2E"), Color.parseColor("#0D0D1A"), (bgAlpha - 60) / 20f)
            else -> interpolateColor(Color.parseColor("#0D0D1A"), Color.parseColor("#000000"), (bgAlpha - 80) / 20f)
        }

        binding.previewCard.setCardBackgroundColor(bgColor)
        binding.previewText.setTextColor(Color.parseColor(settings.textColor))
        binding.previewText.textSize = settings.textSize.toFloat()
        binding.previewText.setLineSpacing(0f, settings.lineSpacing)

        // Update background of entire settings
        binding.root.setBackgroundColor(
            if (settings.backgroundDarkness > 50)
                Color.parseColor("#0F0F1A")
            else
                Color.parseColor("#F5F2EE")
        )

        val toolbarColor = if (settings.backgroundDarkness > 50)
            Color.parseColor("#15151F")
        else
            Color.parseColor("#EDEAE5")

        binding.settingsToolbar.setBackgroundColor(toolbarColor)
        window.statusBarColor = toolbarColor

        val textColor = if (settings.backgroundDarkness > 50) Color.WHITE else Color.parseColor("#1A1A1A")
        binding.settingsTitleText.setTextColor(textColor)
    }

    private fun saveSettings() {
        prefsManager.saveSettings(settings)
    }

    private fun interpolateColor(c1: Int, c2: Int, ratio: Float): Int {
        val r = (Color.red(c1) + ratio * (Color.red(c2) - Color.red(c1))).toInt()
        val g = (Color.green(c1) + ratio * (Color.green(c2) - Color.green(c1))).toInt()
        val b = (Color.blue(c1) + ratio * (Color.blue(c2) - Color.blue(c1))).toInt()
        return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
