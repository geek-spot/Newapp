package com.mdviewer.app.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.mdviewer.app.model.AppSettings

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getSettings(): AppSettings {
        val json = prefs.getString(KEY_SETTINGS, null)
        return if (json != null) {
            try {
                gson.fromJson(json, AppSettings::class.java)
            } catch (e: Exception) {
                AppSettings()
            }
        } else {
            AppSettings()
        }
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit().putString(KEY_SETTINGS, gson.toJson(settings)).apply()
    }

    companion object {
        private const val PREF_NAME = "md_viewer_prefs"
        private const val KEY_SETTINGS = "app_settings"
    }
}
