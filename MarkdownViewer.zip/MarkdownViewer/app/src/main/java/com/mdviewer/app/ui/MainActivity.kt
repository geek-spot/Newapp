package com.mdviewer.app.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import com.google.android.material.snackbar.Snackbar
import com.mdviewer.app.R
import com.mdviewer.app.databinding.ActivityMainBinding
import com.mdviewer.app.model.AppSettings
import com.mdviewer.app.utils.MarkdownRenderer
import com.mdviewer.app.utils.PreferencesManager
import com.mdviewer.app.utils.ThemeHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefsManager: PreferencesManager
    private lateinit var markdownRenderer: MarkdownRenderer
    private var currentUri: Uri? = null
    private var currentContent: String = ""

    private val openFileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                loadFile(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefsManager = PreferencesManager(this)
        markdownRenderer = MarkdownRenderer(this)

        setupToolbar()
        applySettings()
        setupFab()
        showWelcomeScreen()

        // Handle intent (open from file manager)
        intent?.data?.let { uri ->
            loadFile(uri)
        }
    }

    override fun onResume() {
        super.onResume()
        applySettings()
        if (currentContent.isNotEmpty()) {
            renderContent(currentContent)
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
    }

    private fun setupFab() {
        binding.fabOpen.setOnClickListener {
            openFilePicker()
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "text/markdown",
                "text/plain",
                "application/octet-stream"
            ))
        }
        openFileLauncher.launch(intent)
    }

    private fun loadFile(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { stream ->
                val content = stream.bufferedReader(Charsets.UTF_8).readText()
                currentUri = uri
                currentContent = content

                val fileName = getFileName(uri)
                binding.toolbarTitle.text = fileName
                binding.toolbarSubtitle.text = uri.path?.substringBeforeLast("/") ?: ""

                renderContent(content)
                hideWelcomeScreen()
                animateContentIn()
            }
        } catch (e: Exception) {
            Snackbar.make(binding.root, getString(R.string.error_reading_file), Snackbar.LENGTH_LONG)
                .setBackgroundTint(Color.parseColor("#FF5252"))
                .setTextColor(Color.WHITE)
                .show()
        }
    }

    private fun renderContent(content: String) {
        val settings = prefsManager.getSettings()
        applySettings(settings)

        val spanned = markdownRenderer.render(content, settings)
        binding.markdownText.text = spanned
    }

    private fun getFileName(uri: Uri): String {
        var name = "document.md"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }

    private fun applySettings() {
        applySettings(prefsManager.getSettings())
    }

    private fun applySettings(settings: AppSettings) {
        // Background
        val bgAlpha = settings.backgroundDarkness
        val bgColor = when {
            bgAlpha < 30 -> interpolateColor(Color.parseColor("#FAFAF8"), Color.parseColor("#F0EDE8"), bgAlpha / 30f)
            bgAlpha < 60 -> interpolateColor(Color.parseColor("#F0EDE8"), Color.parseColor("#1A1A2E"), (bgAlpha - 30) / 30f)
            bgAlpha < 80 -> interpolateColor(Color.parseColor("#1A1A2E"), Color.parseColor("#0D0D1A"), (bgAlpha - 60) / 20f)
            else -> interpolateColor(Color.parseColor("#0D0D1A"), Color.parseColor("#000000"), (bgAlpha - 80) / 20f)
        }

        binding.root.setBackgroundColor(bgColor)
        binding.scrollView.setBackgroundColor(bgColor)
        binding.contentCard.setCardBackgroundColor(adjustCardColor(bgColor))

        // Toolbar color
        val toolbarColor = darkenColor(bgColor, 0.15f)
        binding.toolbar.setBackgroundColor(toolbarColor)
        window.statusBarColor = toolbarColor
        window.navigationBarColor = bgColor

        // Text color
        val textColor = Color.parseColor(settings.textColor)
        binding.markdownText.setTextColor(textColor)
        binding.toolbarTitle.setTextColor(textColor)

        val subtitleColor = Color.argb(160, Color.red(textColor), Color.green(textColor), Color.blue(textColor))
        binding.toolbarSubtitle.setTextColor(subtitleColor)

        // Text size
        binding.markdownText.textSize = settings.textSize.toFloat()

        // Line spacing
        binding.markdownText.setLineSpacing(0f, 1.8f)

        // RTL support for Persian
        binding.markdownText.textDirection = View.TEXT_DIRECTION_LOCALE

        // Icon tints
        val iconColor = if (isDarkBackground(bgColor)) Color.WHITE else Color.parseColor("#2C2C2C")
        binding.toolbar.navigationIcon?.setTint(iconColor)
        ThemeHelper.tintMenuIcons(binding.toolbar, iconColor)
    }

    private fun isDarkBackground(color: Int): Boolean {
        val r = Color.red(color) / 255.0
        val g = Color.green(color) / 255.0
        val b = Color.blue(color) / 255.0
        val luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
        return luminance < 0.5
    }

    private fun interpolateColor(c1: Int, c2: Int, ratio: Float): Int {
        val r = (Color.red(c1) + ratio * (Color.red(c2) - Color.red(c1))).toInt()
        val g = (Color.green(c1) + ratio * (Color.green(c2) - Color.green(c1))).toInt()
        val b = (Color.blue(c1) + ratio * (Color.blue(c2) - Color.blue(c1))).toInt()
        return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), b.coerceIn(0, 255))
    }

    private fun adjustCardColor(bgColor: Int): Int {
        return if (isDarkBackground(bgColor)) {
            lightenColor(bgColor, 0.05f)
        } else {
            darkenColor(bgColor, 0.02f)
        }
    }

    private fun lightenColor(color: Int, factor: Float): Int {
        val r = (Color.red(color) + (255 - Color.red(color)) * factor).toInt().coerceIn(0, 255)
        val g = (Color.green(color) + (255 - Color.green(color)) * factor).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) + (255 - Color.blue(color)) * factor).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun darkenColor(color: Int, factor: Float): Int {
        val r = (Color.red(color) * (1 - factor)).toInt().coerceIn(0, 255)
        val g = (Color.green(color) * (1 - factor)).toInt().coerceIn(0, 255)
        val b = (Color.blue(color) * (1 - factor)).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun showWelcomeScreen() {
        binding.welcomeLayout.visibility = View.VISIBLE
        binding.contentCard.visibility = View.GONE
    }

    private fun hideWelcomeScreen() {
        binding.welcomeLayout.visibility = View.GONE
        binding.contentCard.visibility = View.VISIBLE
    }

    private fun animateContentIn() {
        binding.contentCard.alpha = 0f
        binding.contentCard.translationY = 40f

        val fadeIn = ObjectAnimator.ofFloat(binding.contentCard, "alpha", 0f, 1f)
        val slideUp = ObjectAnimator.ofFloat(binding.contentCard, "translationY", 40f, 0f)

        AnimatorSet().apply {
            playTogether(fadeIn, slideUp)
            duration = 400
            interpolator = DecelerateInterpolator()
            start()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_open -> {
                openFilePicker()
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_reload -> {
                currentUri?.let { loadFile(it) }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
