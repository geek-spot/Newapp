package com.mdviewer.app.utils

import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import androidx.appcompat.widget.Toolbar

object ThemeHelper {
    fun tintMenuIcons(toolbar: Toolbar, color: Int) {
        try {
            val menu = toolbar.menu
            for (i in 0 until menu.size()) {
                menu.getItem(i).icon?.setColorFilter(color, PorterDuff.Mode.SRC_IN)
            }
        } catch (_: Exception) {}
    }
}
