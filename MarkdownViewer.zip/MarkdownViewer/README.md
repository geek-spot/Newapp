# 📄 نمایشگر Markdown فارسی

یک اپلیکیشن اندروید مدرن برای نمایش فایل‌های Markdown با پشتیبانی کامل از متن‌های فارسی و فونت وزیرمتن.

---

## ✨ ویژگی‌ها

- 🔤 **فونت وزیرمتن** — فونت اختصاصی فارسی برای خوانایی بهتر
- 🌑 **تاریکی پس‌زمینه قابل تنظیم** — از سفید خالص تا شب کامل
- 🎨 **انتخاب رنگ متن** — 9 رنگ از جمله کرم گرم، بژ و آبی ملایم
- 🔠 **اندازه فونت قابل تنظیم** — از 12sp تا 32sp
- 📏 **فاصله خط و پاراگراف** — بهینه برای متون فارسی
- 📱 **RTL کامل** — پشتیبانی از راست‌به‌چپ
- 💻 **رنگ‌بندی کد** — Syntax highlighting با Markwon
- 📊 **جداول، لیست‌ها، Blockquote** — تمام عناصر Markdown
- 🔗 **باز کردن از فایل‌منیجر** — پشتیبانی از Intent
- 🔄 **بارگذاری مجدد** — Reload سریع

---

## 🚀 راه‌اندازی

### ۱. دانلود فونت وزیرمتن

فونت‌های وزیرمتن را از [GitHub رسمی](https://github.com/rastikerdar/vazirmatn/releases) دانلود کنید.

فایل‌های مورد نیاز:
```
Vazirmatn-Regular.ttf  →  app/src/main/res/font/vazirmatn.ttf
Vazirmatn-Bold.ttf     →  app/src/main/res/font/vazirmatn_bold.ttf
```

همچنین کپی در:
```
app/src/main/assets/fonts/Vazirmatn-Regular.ttf
app/src/main/assets/fonts/Vazirmatn-Bold.ttf
```

### ۲. Build پروژه

```bash
cd MarkdownViewer
./gradlew assembleDebug
```

فایل APK در:
```
app/build/outputs/apk/debug/app-debug.apk
```

### ۳. نصب روی دستگاه

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 📁 ساختار پروژه

```
MarkdownViewer/
├── app/src/main/
│   ├── java/com/mdviewer/app/
│   │   ├── ui/
│   │   │   ├── MainActivity.kt        ← صفحه اصلی
│   │   │   └── SettingsActivity.kt    ← صفحه تنظیمات
│   │   ├── model/
│   │   │   └── AppSettings.kt         ← مدل تنظیمات
│   │   └── utils/
│   │       ├── MarkdownRenderer.kt    ← رندر Markdown
│   │       ├── PreferencesManager.kt  ← ذخیره تنظیمات
│   │       └── ThemeHelper.kt         ← کمک‌های تم
│   ├── res/
│   │   ├── layout/
│   │   │   ├── activity_main.xml
│   │   │   ├── activity_settings.xml
│   │   │   └── item_color_chip.xml
│   │   ├── font/                      ← فایل‌های TTF اینجا
│   │   └── drawable/
│   └── assets/fonts/                  ← فایل‌های TTF اینجا هم
```

---

## 🎨 طراحی

- **تم**: تاریک مدرن با تأکید سبز فیروزه‌ای (#7EB8A5)
- **رنگ‌بندی**: بهینه برای متون فارسی طولانی
- **کارت‌ها**: Material 3 با گوشه‌های گرد
- **انیمیشن‌ها**: Fade و Slide برای ورود محتوا

---

## 📦 Dependencies

| کتابخانه | نسخه | کاربرد |
|---------|------|--------|
| Markwon | 4.6.2 | رندر Markdown |
| Material3 | 1.11.0 | UI Components |
| Gson | 2.10.1 | ذخیره تنظیمات |

---

## 📝 نمونه Markdown پشتیبانی‌شده

```markdown
# عنوان اصلی
## عنوان دوم

**متن پررنگ** و *متن کج* و ~~خط‌خورده~~

- آیتم اول
- آیتم دوم
  - زیرآیتم

1. مرحله اول
2. مرحله دوم

> این یک نقل‌قول است

`کد درون‌خطی`

```python
def سلام():
    print("سلام دنیا!")
```

| ستون ۱ | ستون ۲ |
|--------|--------|
| مقدار | مقدار |
```
